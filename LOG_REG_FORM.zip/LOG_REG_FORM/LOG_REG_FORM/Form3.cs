﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace LOG_REG_FORM
{
    public partial class hellow : Form
    {
        int totalrecords = 0;
        int currentrecord = 0;

        public hellow()
        {
            InitializeComponent();
        }

        private void hellow_Load(object sender, EventArgs e)
        {
            String sql = "select * from reg where fnm='" + txtnm + "' and email='" + txtemail + "' ";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable(); 
            totalrecords = dt.Rows.Count;
            txtnm.Text = dt.Rows[currentrecord]["fnm"].ToString();
            txtemail.Text = dt.Rows[currentrecord]["password"].ToString();
            da.Fill(dt);

        }
    }
}
